/* global variables */
node     *dummyNode;            /* for sentinel uses */
